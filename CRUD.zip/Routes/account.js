const e = require("express");
const express = require("express")
const accountRoutes = express.Router();
const fs = require('fs');
const path = require('path');
const { MIMEType } = require("util");

const dataPath = './Details/useraccount.json' 

// util functions 

const saveAccountData = (data) => {
    const stringifyData = JSON.stringify(data)
    fs.writeFileSync(dataPath, stringifyData)
}

const getAccountData = () => {
    const jsonData = fs.readFileSync(dataPath)
    return JSON.parse(jsonData)    
}


// reading the data
accountRoutes.get('/account', (req, res) => {
    fs.readFile(dataPath, 'utf8', (err, data) => {
      if (err) {
        throw err;
      }

      res.send(JSON.parse(data));
    });
  });


  accountRoutes.post('/account/addaccount', (req, res) => {
    var existAccounts = getAccountData();
    const newAccountId = Math.floor(100000 + Math.random() * 900000);
    const image = req.body.image; // Assuming the image is sent as a base64 data URL
    const base64Data = image.replace(/^data:.+;base64,/, '');
    const byteCharacters = atob(base64Data); // Decode Base64 string
    const byteNumbers = new Array(byteCharacters.length);

    for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }

    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: MIMEType });

    //save blob in uploads directory
    const filePath = path.join(__dirname, '../uploads', `${accountId}.jpg`); // Change the file extension as needed
    const fileStream = fs.createWriteStream(filePath);
    fileStream.write(byteArray, (err) => {
        if (err) {
            console.error('Error writing file:', err);
        } else {
            console.log('File saved successfully:', filePath);
        }
    });
      existAccounts[newAccountId] = req.body;

      saveAccountData(existAccounts);
      res.send({ success: true, msg: 'Account data added successfully (no image provided)' });
    }
  );

// Read - get all accounts from the json file
accountRoutes.get('/account/list', (req, res) => {
  const accounts = getAccountData()
  res.send(accounts)
})

// Read - get a specific account from the json file
accountRoutes.get('/account/:id', (req, res) => {
  const accountId = req.params['id'];
  const accounts = getAccountData()

  if (accounts[accountId]) {
    res.send(accounts[accountId])
  } else {
    res.status(404).send({ error: 'Account not found' })
  }
})

// Update - using Put method
accountRoutes.put('/account/:id', (req, res) => {
  // show the data in the console
  console.log(req.body)
  var existAccounts = getAccountData();
  const accountId = req.params['id'];

  // convert data url image to a file and then save it to the uploads directory
    const image = req.body.image; // Assuming the image is sent as a base64 data URL
    const base64Data = image.replace(/^data:.+;base64,/, '');
    const byteCharacters = atob(base64Data); // Decode Base64 string
    const byteNumbers = new Array(byteCharacters.length);

    for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }

    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: MIMEType });

    //save blob in uploads directory
    const filePath = path.join(__dirname, '../uploads', `${accountId}.jpg`); // Change the file extension as needed
    const fileStream = fs.createWriteStream(filePath);
    fileStream.write(byteArray, (err) => {
        if (err) {
            console.error('Error writing file:', err);
        } else {
            console.log('File saved successfully:', filePath);
        }
    });
  
    // If no image is provided, just update the account data
    existAccounts[accountId] = req.body;
    saveAccountData(existAccounts);
    res.send({ success: true, msg: `Account with id ${accountId} has been updated` });
  
});

//delete - using delete method
accountRoutes.delete('/account/delete/:id', (req, res) => {
  const userId = req.params['id'];
    fs.readFile(dataPath, 'utf8', (err, data) => {
      var existAccounts = getAccountData()
      if (!existAccounts[userId]) {
        return res.status(404).send({ success: false, msg: 'UserId not found' });
      }
  
      delete existAccounts[userId];  
      saveAccountData(existAccounts);
    }, true);
    res.send(`account with id ${userId} has been deleted`)
})

// Route to serve the index.html file
accountRoutes.get('/', (req, res) => {
  const indexPath = path.join(__dirname, '../views/index.html');
  res.sendFile(indexPath);
});
module.exports = accountRoutes